package dev.weaponcraft;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/** /weapons menu + the Gambling Slot (/roll weapons). */
final class Gui implements Listener {
    static final class WMenu implements InventoryHolder {
        Inventory inv;
        public Inventory getInventory() { return inv; }
    }
    static final class SlotMenu implements InventoryHolder {
        Inventory inv;
        boolean rolling;
        public Inventory getInventory() { return inv; }
    }

    static final int[] INPUT = {10, 11, 12, 13, 14};
    static final int ROLL = 16, INFO = 8, POINTER = 4;
    static final int[] REEL = {19, 20, 21, 22, 23, 24, 25};

    /** rare item -> chance points (%) per item */
    static final Map<Material, Integer> RARE = Map.ofEntries(
            Map.entry(Material.EMERALD, 2), Map.entry(Material.DIAMOND, 3),
            Map.entry(Material.ANCIENT_DEBRIS, 5), Map.entry(Material.ENCHANTED_GOLDEN_APPLE, 6),
            Map.entry(Material.NETHERITE_INGOT, 8), Map.entry(Material.TOTEM_OF_UNDYING, 8),
            Map.entry(Material.HEART_OF_THE_SEA, 10), Map.entry(Material.ELYTRA, 12),
            Map.entry(Material.NETHER_STAR, 15), Map.entry(Material.DRAGON_EGG, 25));

    static ItemStack icon(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(Weapon.t(name));
        if (lore.length > 0) { List<Component> l = new ArrayList<>(); for (String s : lore) l.add(Weapon.t(s)); meta.lore(l); }
        it.setItemMeta(meta);
        return it;
    }
    static ItemStack filler() { return icon(Material.GRAY_STAINED_GLASS_PANE, " "); }
    static ItemStack brownDye() {
        return icon(Material.BROWN_DYE, "<#8B4513>literally shit", "<gray>You gambled.", "<gray>You lost.");
    }

    // -------------------------------------------------------------- weapon menu
    static void openWeapons(Player p) {
        WMenu h = new WMenu();
        h.inv = Bukkit.createInventory(h, 27, Weapon.t("<gradient:#ff5a00:#ffd000><bold>WeaponCraft"));
        for (int i = 0; i < 27; i++) h.inv.setItem(i, filler());
        Weapon[] ws = Weapon.values();
        for (int i = 0; i < ws.length; i++) h.inv.setItem(10 + i, ws[i].create());
        h.inv.setItem(22, Weapon.slotItem());
        p.openInventory(h.inv);
    }

    // -------------------------------------------------------------- gambling slot
    static void openSlot(Player p) {
        SlotMenu h = new SlotMenu();
        h.inv = Bukkit.createInventory(h, 27, Weapon.t("<gradient:#ffd000:#ff7a00><bold>Gambling Slot"));
        for (int i = 0; i < 27; i++) h.inv.setItem(i, filler());
        for (int s : INPUT) h.inv.setItem(s, null);
        for (int s : REEL) h.inv.setItem(s, icon(Material.BLACK_STAINED_GLASS_PANE, " "));
        h.inv.setItem(POINTER, icon(Material.HOPPER, "<gold>▼ result ▼"));
        h.inv.setItem(ROLL, icon(Material.LIME_CONCRETE, "<green><bold>ROLL", "<gray>Consumes the items in the slots."));
        updateInfo(h);
        p.openInventory(h.inv);
    }

    static double base() { return WeaponCraft.get().getConfig().getDouble("gambling.base-chance", 2.0); }
    static double max() { return WeaponCraft.get().getConfig().getDouble("gambling.max-chance", 75.0); }

    static int points(SlotMenu sm) {
        int sum = 0;
        for (int s : INPUT) {
            ItemStack it = sm.inv.getItem(s);
            if (it != null && RARE.containsKey(it.getType())) sum += RARE.get(it.getType()) * it.getAmount();
        }
        return sum;
    }

    static void updateInfo(SlotMenu sm) {
        int pts = points(sm);
        double chance = pts <= 0 ? 0 : Math.min(max(), base() + pts);
        List<String> lore = new ArrayList<>();
        lore.add("<gray>Gold weapon chance: <gold>" + String.format("%.1f", chance) + "%");
        lore.add("");
        lore.add("<gray>Rare items (+% each):");
        RARE.entrySet().stream().sorted(Map.Entry.comparingByValue())
                .forEach(en -> lore.add("<dark_gray>• <white>" + en.getKey().name().toLowerCase().replace('_', ' ') + " <gold>+" + en.getValue()));
        sm.inv.setItem(INFO, icon(Material.NETHER_STAR, "<gold><bold>Odds", lore.toArray(new String[0])));
    }

    static void roll(Player p, SlotMenu sm) {
        int pts = points(sm);
        if (pts <= 0) { p.sendMessage(Weapon.t("<red>Put rare items in the slots first.")); return; }
        double chance = Math.min(max(), base() + pts);
        for (int s : INPUT) sm.inv.setItem(s, null);
        sm.rolling = true;
        updateInfo(sm);
        boolean win = ThreadLocalRandom.current().nextDouble(100) < chance;
        ItemStack result = win ? Weapon.MIDAS_REAVER.create() : brownDye();

        List<ItemStack> pool = new ArrayList<>();
        for (Weapon w : Weapon.values()) pool.add(w.create());
        pool.add(brownDye()); pool.add(brownDye());
        ItemStack[] reel = new ItemStack[30];
        for (int i = 0; i < reel.length; i++) reel[i] = pool.get(ThreadLocalRandom.current().nextInt(pool.size())).clone();
        reel[26] = result.clone(); // centre of the final window (s=23, centre = s+3)
        step(p, sm, reel, 0, result, win, chance);
    }

    static void step(Player p, SlotMenu sm, ItemStack[] reel, int s, ItemStack result, boolean win, double chance) {
        for (int i = 0; i < 7; i++) sm.inv.setItem(REEL[i], reel[s + i]);
        if (p.isOnline()) p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 0.8f, 1.0f + s * 0.03f);
        if (s >= 23) { finish(p, sm, result, win); return; }
        int delay = s < 12 ? 2 : s < 18 ? 3 : s < 21 ? 5 : 8;
        Bukkit.getScheduler().runTaskLater(WeaponCraft.get(), () -> step(p, sm, reel, s + 1, result, win, chance), delay);
    }

    static void finish(Player p, SlotMenu sm, ItemStack result, boolean win) {
        if (p.isOnline()) {
            Map<Integer, ItemStack> left = p.getInventory().addItem(result.clone());
            left.values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
            if (win) {
                p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
                p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, p.getLocation().add(0, 1, 0), 80, 0.6, 1, 0.6, 0.4);
                Bukkit.broadcast(Weapon.t("<gold>" + p.getName() + " <yellow>just rolled the <gradient:#ffb300:#fff3a0>Midas Reaver<yellow>!"));
            } else {
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 0.6f);
                p.sendMessage(Weapon.t("<#8B4513>literally shit<gray>. Better luck next time."));
            }
        }
        Bukkit.getScheduler().runTaskLater(WeaponCraft.get(), () -> { sm.rolling = false; updateInfo(sm); }, 30);
    }

    // -------------------------------------------------------------- events
    @EventHandler
    public void click(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        Player p = (Player) e.getWhoClicked();
        if (top.getHolder() instanceof WMenu) {
            e.setCancelled(true);
            if (e.getClickedInventory() != top) return;
            ItemStack it = e.getCurrentItem();
            if (it == null) return;
            if (Weapon.isSlot(it)) {
                if (!p.hasPermission("weaponcraft.admin")) { p.sendMessage(Weapon.t("<gray>Use <gold>/roll weapons<gray> to open the slot.")); return; }
                p.getInventory().addItem(Weapon.slotItem());
                return;
            }
            Weapon w = Weapon.of(it);
            if (w == null) return;
            if (w == Weapon.MIDAS_REAVER && !p.hasPermission("weaponcraft.admin")) {
                p.sendMessage(Weapon.t("<gold>The Midas Reaver<gray> can only be won from the Gambling Slot (<gold>/roll weapons<gray>)."));
                return;
            }
            if (!p.hasPermission("weaponcraft.give")) return;
            p.getInventory().addItem(w.create());
            p.playSound(p.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1f, 1f);
            return;
        }
        if (top.getHolder() instanceof SlotMenu sm) {
            if (sm.rolling) { e.setCancelled(true); return; }
            int raw = e.getRawSlot();
            if (raw < 27) {
                boolean input = false;
                for (int s : INPUT) if (s == raw) input = true;
                if (!input) {
                    e.setCancelled(true);
                    if (raw == ROLL) roll(p, sm);
                } else {
                    ClickType c = e.getClick();
                    boolean ok = c == ClickType.LEFT || c == ClickType.RIGHT || c == ClickType.SHIFT_LEFT || c == ClickType.SHIFT_RIGHT;
                    ItemStack cur = e.getCursor();
                    if (!ok || (cur != null && !cur.getType().isAir() && !RARE.containsKey(cur.getType()))) e.setCancelled(true);
                }
            } else if (e.isShiftClick()) {
                e.setCancelled(true); // keep it simple: place rare items by hand
            }
            Bukkit.getScheduler().runTask(WeaponCraft.get(), () -> updateInfo(sm));
        }
    }

    @EventHandler
    public void drag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (top.getHolder() instanceof WMenu) { e.setCancelled(true); return; }
        if (top.getHolder() instanceof SlotMenu sm) {
            ItemStack cur = e.getOldCursor();
            boolean bad = sm.rolling || !RARE.containsKey(cur.getType());
            for (int raw : e.getRawSlots()) {
                if (raw >= 27) continue;
                boolean input = false;
                for (int s : INPUT) if (s == raw) input = true;
                if (!input || bad) { e.setCancelled(true); return; }
            }
            Bukkit.getScheduler().runTask(WeaponCraft.get(), () -> updateInfo(sm));
        }
    }

    @EventHandler
    public void close(InventoryCloseEvent e) {
        if (e.getInventory().getHolder() instanceof SlotMenu sm && !sm.rolling) {
            Player p = (Player) e.getPlayer();
            for (int s : INPUT) {
                ItemStack it = sm.inv.getItem(s);
                if (it == null) continue;
                sm.inv.setItem(s, null);
                p.getInventory().addItem(it).values().forEach(i -> p.getWorld().dropItemNaturally(p.getLocation(), i));
            }
        }
    }
}
