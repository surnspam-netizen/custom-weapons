package dev.weaponcraft;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

final class Listeners implements Listener {

    @EventHandler
    public void interact(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack it = e.getItem();
        if (it == null) return;
        Player p = e.getPlayer();
        if (Weapon.isSlot(it)) { e.setCancelled(true); Gui.openSlot(p); return; }
        Weapon w = Weapon.of(it);
        if (w == null) return;
        e.setCancelled(true); // stops bow draw, log stripping, tilling...
        Abilities.use(p, w, p.isSneaking() ? 2 : 1);
    }

    /** F key = ability 2 */
    @EventHandler
    public void swap(PlayerSwapHandItemsEvent e) {
        Weapon w = Weapon.of(e.getOffHandItem()); // the item that WAS in the main hand
        if (w == null) return;
        e.setCancelled(true);
        Abilities.use(e.getPlayer(), w, 2);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void damaged(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player v && Abilities.absorbing(v)) {
            e.setDamage(Abilities.absorb(v, e.getDamage()));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void stunnedAttack(EntityDamageByEntityEvent e) {
        if (Abilities.isStunned(e.getDamager())) e.setCancelled(true);
    }

    @EventHandler
    public void move(PlayerMoveEvent e) {
        if (!Abilities.isStunned(e.getPlayer())) return;
        Location f = e.getFrom(), t = e.getTo();
        if (t == null) return;
        if (f.getX() != t.getX() || f.getY() != t.getY() || f.getZ() != t.getZ()) {
            Location n = f.clone();
            n.setYaw(t.getYaw());
            n.setPitch(t.getPitch());
            e.setTo(n);
        }
    }

    @EventHandler
    public void quit(PlayerQuitEvent e) { Abilities.clear(e.getPlayer()); }
}
