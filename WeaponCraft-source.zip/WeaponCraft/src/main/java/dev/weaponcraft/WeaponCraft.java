package dev.weaponcraft;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public final class WeaponCraft extends JavaPlugin implements Listener {
    private static WeaponCraft inst;
    public static WeaponCraft get() { return inst; }

    @Override
    public void onEnable() {
        inst = this;
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(new Listeners(), this);
        Bukkit.getPluginManager().registerEvents(new Gui(), this);
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("WeaponCraft enabled - 7 weapons loaded.");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        String url = getConfig().getString("resource-pack.url", "");
        if (url == null || url.isBlank()) return;
        String sha = getConfig().getString("resource-pack.sha1", "");
        boolean force = getConfig().getBoolean("resource-pack.force", false);
        Bukkit.getScheduler().runTaskLater(this, () -> e.getPlayer().setResourcePack(url, sha, force), 20L);
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!(s instanceof Player p)) { s.sendMessage("Players only."); return true; }
        switch (c.getName().toLowerCase()) {
            case "weapons" -> Gui.openWeapons(p);
            case "roll" -> {
                if (a.length >= 1 && a[0].equalsIgnoreCase("weapons")) Gui.openSlot(p);
                else p.sendMessage(Component.text("Usage: /roll weapons", NamedTextColor.GOLD));
            }
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (c.getName().equalsIgnoreCase("roll") && a.length == 1) return List.of("weapons");
        return List.of();
    }
}
