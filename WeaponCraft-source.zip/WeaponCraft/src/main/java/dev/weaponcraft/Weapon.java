package dev.weaponcraft;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public enum Weapon {
    BLOODBORN("bloodborn", "<gradient:#6b0000:#ff2a2a><bold>Bloodborn", Material.NETHERITE_SWORD,
            "Blood Chain", "Claw out of the blade, chain an enemy and drag them in.", 8,
            "Crimson Step", "Teleport behind an enemy in crimson lightning.", 14,
            "A blade that never stops thirsting."),
    WILDCARE("wildcare", "<gradient:#1fa84f:#b6ff7a><bold>Wildcare", Material.BLAZE_ROD,
            "Verdant Beam", "Fire a huge green beam from the pearl.", 6,
            "Grove of Life", "Grow a tree that heals you for 5 seconds.", 25,
            "The pearl hums with old forests."),
    LIGHTNING_CUTLASS("lightning_cutlass", "<gradient:#4aa8ff:#e8fbff><bold>Lightning Cutlass", Material.IRON_SWORD,
            "Storm Drake", "A lightning dragon grabs an enemy and drops them from 25 blocks.", 30,
            "Static Absorb", "For 8s absorb 30% of the damage you take and heal it.", 20,
            "Forged in the eye of a storm."),
    VOID_BOW("void_bow", "<gradient:#3a0a7a:#b07bff><bold>Void Bow", Material.BOW,
            "Void Volley", "Shoot 3 transparent void arrows.", 5,
            "Convergence", "Merge all 3 arrows into one huge hit. Only usable while Void Volley is ready.", 12,
            "Arrows that forgot the shape of the world."),
    WARLOCKS_AXE("warlocks_axe", "<gradient:#ff5a00:#ffd000><bold>Warlock's Axe", Material.NETHERITE_AXE,
            "Eruption", "Summon a mini volcano for 10s that ignites everyone near it.", 25,
            "Shield Shatter", "Break shields nearby: 30% durability, ignores Unbreaking.", 15,
            "A war axe still warm from the pit."),
    DEATHS_HOOK("deaths_hook", "<gradient:#111111:#7a3dff><bold>Death's Hook", Material.NETHERITE_HOE,
            "Soul Haul", "Pull everything within 30 blocks to you.", 20,
            "Black Lightning", "Stun nearby enemies with black lightning for 3s.", 18,
            "It always collects."),
    MIDAS_REAVER("midas_reaver", "<gradient:#ffb300:#fff3a0><bold>Midas Reaver", Material.GOLDEN_SWORD,
            "Gilded Nova", "A golden shockwave that blasts everything near you.", 10,
            "Coin Barrage", "Fire 5 golden coins.", 8,
            "The gold weapon. Only the Gambling Slot hands these out.");

    public final String id, name, a1, d1, a2, d2, flavor;
    public final Material mat;
    public final int cd1, cd2;
    static final MiniMessage MM = MiniMessage.miniMessage();

    Weapon(String id, String name, Material mat, String a1, String d1, int cd1, String a2, String d2, int cd2, String flavor) {
        this.id = id; this.name = name; this.mat = mat; this.a1 = a1; this.d1 = d1; this.cd1 = cd1;
        this.a2 = a2; this.d2 = d2; this.cd2 = cd2; this.flavor = flavor;
    }

    static NamespacedKey key() { return new NamespacedKey(WeaponCraft.get(), "weapon"); }
    static Component t(String mm) { return MM.deserialize("<!italic>" + mm); }

    public ItemStack create() {
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.displayName(t(name));
        List<Component> lore = new ArrayList<>();
        lore.add(t("<gray>" + flavor));
        lore.add(Component.empty());
        lore.add(t("<yellow>Right-click <white>» <gold>" + a1 + " <dark_gray>(" + cd1 + "s)"));
        lore.add(t("<gray>" + d1));
        lore.add(t("<yellow>Sneak+Right-click / F <white>» <gold>" + a2 + " <dark_gray>(" + cd2 + "s)"));
        lore.add(t("<gray>" + d2));
        m.lore(lore);
        m.setUnbreakable(true);
        m.addItemFlags(ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ATTRIBUTES);
        m.setItemModel(NamespacedKey.fromString("weaponcraft:" + id));
        m.getPersistentDataContainer().set(key(), PersistentDataType.STRING, id);
        it.setItemMeta(m);
        return it;
    }

    public static Weapon of(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        String v = it.getItemMeta().getPersistentDataContainer().get(key(), PersistentDataType.STRING);
        if (v == null) return null;
        for (Weapon w : values()) if (w.id.equals(v)) return w;
        return null;
    }

    public static ItemStack slotItem() {
        ItemStack it = new ItemStack(Material.CLOCK);
        ItemMeta m = it.getItemMeta();
        m.displayName(t("<gradient:#ffd000:#ff7a00><bold>Gambling Slot"));
        m.lore(List.of(t("<gray>Right-click (or /roll weapons)."), t("<gray>Feed it rare items to raise the"), t("<gray>chance of the <gold>gold weapon<gray>."), t("<dark_red>Fail and you get... something.")));
        m.setItemModel(NamespacedKey.fromString("weaponcraft:gambling_slot"));
        m.getPersistentDataContainer().set(key(), PersistentDataType.STRING, "slot");
        it.setItemMeta(m);
        return it;
    }

    public static boolean isSlot(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return false;
        return "slot".equals(it.getItemMeta().getPersistentDataContainer().get(key(), PersistentDataType.STRING));
    }
}
