package dev.weaponcraft;

import org.bukkit.*;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

/** Particle helpers. Vanilla particles are naturally translucent = the "transparent VFX". */
final class Fx {
    static final Vector UP = new Vector(0, 1, 0);

    static void dust(Location l, int r, int g, int b, float size, int n, double spread) {
        l.getWorld().spawnParticle(Particle.DUST, l, n, spread, spread, spread, 0,
                new Particle.DustOptions(Color.fromRGB(r, g, b), size), true);
    }

    static void p(Location l, Particle pt, int n, double spread, double speed) {
        l.getWorld().spawnParticle(pt, l, n, spread, spread, spread, speed, null, true);
    }

    /** count=0 trick: offsets become the direction. */
    static void dir(Location l, Particle pt, Vector v, double speed) {
        l.getWorld().spawnParticle(pt, l, 0, v.getX(), v.getY(), v.getZ(), speed, null, true);
    }

    static double rnd(double a, double b) { return ThreadLocalRandom.current().nextDouble(a, b); }

    static void line(Location a, Location b, double step, BiConsumer<Location, Integer> f) {
        Vector v = b.toVector().subtract(a.toVector());
        double len = v.length();
        if (len < 1e-4) return;
        v.normalize().multiply(step);
        Location cur = a.clone();
        int i = 0;
        for (double d = 0; d < len; d += step, i++) { f.accept(cur.clone(), i); cur.add(v); }
    }

    static void ring(Location c, double r, int pts, Consumer<Location> f) {
        for (int i = 0; i < pts; i++) {
            double a = i * Math.PI * 2 / pts;
            f.accept(c.clone().add(Math.cos(a) * r, 0, Math.sin(a) * r));
        }
    }

    /** right + up basis perpendicular to d */
    static Vector[] basis(Vector d) {
        Vector right = Math.abs(d.getY()) > 0.98 ? new Vector(1, 0, 0) : d.clone().crossProduct(UP).normalize();
        Vector up = right.clone().crossProduct(d).normalize();
        return new Vector[]{right, up};
    }

    static void bolt(Location base, int r, int g, int b) {
        Location cur = base.clone().add(0, 14, 0);
        while (cur.getY() > base.getY()) {
            Location next = cur.clone().add(rnd(-0.9, 0.9), -1.3, rnd(-0.9, 0.9));
            line(cur, next, 0.2, (l, i) -> {
                dust(l, r, g, b, 2.2f, 2, 0.04);
                if (i % 3 == 0) p(l, Particle.ELECTRIC_SPARK, 1, 0.1, 0.02);
            });
            cur = next;
        }
        dust(base, r, g, b, 3f, 10, 0.5);
    }
}
