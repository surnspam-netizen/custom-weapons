package dev.weaponcraft;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.*;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.attribute.Attribute;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

final class Abilities {
    private static final Map<UUID, Map<String, Long>> CD = new HashMap<>();
    private static final Map<UUID, Long> ABSORB = new HashMap<>();
    private static final Map<UUID, Long> STUN = new HashMap<>();

    private static WeaponCraft pl() { return WeaponCraft.get(); }

    // ------------------------------------------------------------------ cooldowns / dispatch
    static long left(Player p, String key) {
        Long u = CD.getOrDefault(p.getUniqueId(), Map.of()).get(key);
        return u == null ? 0 : Math.max(0, u - System.currentTimeMillis());
    }
    static void cd(Player p, String key, int sec) {
        CD.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>()).put(key, System.currentTimeMillis() + sec * 1000L);
    }
    static boolean fail(Player p, String msg) {
        p.sendActionBar(Component.text(msg, NamedTextColor.RED));
        return false;
    }
    static void clear(Player p) { CD.remove(p.getUniqueId()); ABSORB.remove(p.getUniqueId()); STUN.remove(p.getUniqueId()); }

    static void use(Player p, Weapon w, int which) {
        if (isStunned(p)) return;
        String key = w.id + ":" + which;
        long left = left(p, key);
        if (left > 0) {
            p.sendActionBar(Component.text((which == 1 ? w.a1 : w.a2) + " ready in " + String.format("%.1f", left / 1000.0) + "s", NamedTextColor.GRAY));
            return;
        }
        boolean ok = switch (w) {
            case BLOODBORN -> which == 1 ? bloodChain(p) : crimsonStep(p);
            case WILDCARE -> which == 1 ? verdantBeam(p) : grove(p);
            case LIGHTNING_CUTLASS -> which == 1 ? stormDrake(p) : staticAbsorb(p);
            case VOID_BOW -> which == 1 ? voidVolley(p) : convergence(p);
            case WARLOCKS_AXE -> which == 1 ? volcano(p) : shatter(p);
            case DEATHS_HOOK -> which == 1 ? soulHaul(p) : blackLightning(p);
            case MIDAS_REAVER -> which == 1 ? gildedNova(p) : coinBarrage(p);
        };
        if (ok) cd(p, key, which == 1 ? w.cd1 : w.cd2);
    }

    // ------------------------------------------------------------------ helpers
    static LivingEntity target(Player p, double range) {
        Location e = p.getEyeLocation();
        RayTraceResult r = p.getWorld().rayTraceEntities(e, e.getDirection(), range, 0.9,
                x -> x instanceof LivingEntity && !x.equals(p) && !(x instanceof ArmorStand));
        return r == null ? null : (LivingEntity) r.getHitEntity();
    }
    static Location center(LivingEntity e) { return e.getLocation().add(0, e.getHeight() / 2, 0); }
    static Location hand(Player p) {
        Location e = p.getEyeLocation();
        Vector d = e.getDirection();
        Vector right = d.clone().crossProduct(Fx.UP).normalize();
        return e.add(d.multiply(0.8)).add(right.multiply(0.35)).add(0, -0.35, 0);
    }
    static boolean isStunned(Entity e) {
        Long u = STUN.get(e.getUniqueId());
        return u != null && u > System.currentTimeMillis();
    }
    static boolean absorbing(Player p) {
        Long u = ABSORB.get(p.getUniqueId());
        return u != null && u > System.currentTimeMillis();
    }
    /** returns new damage after absorbing 30%, heals the player by the absorbed amount */
    static double absorb(Player p, double dmg) {
        double a = dmg * 0.30;
        double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
        Bukkit.getScheduler().runTask(pl(), () -> p.setHealth(Math.min(max, p.getHealth() + a)));
        Location c = p.getLocation().add(0, 1, 0);
        Fx.p(c, Particle.ELECTRIC_SPARK, 25, 0.5, 0.3);
        Fx.dust(c, 120, 210, 255, 1.6f, 12, 0.5);
        p.getWorld().playSound(c, Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 0.8f, 1.8f);
        return dmg - a;
    }

    // Animated block display (smooth interpolation)
    static BlockDisplay part(Location base, BlockData bd, float sx, float sy, float sz, float y, boolean glow, int growTicks, int delay) {
        BlockDisplay d = base.getWorld().spawn(base, BlockDisplay.class, e -> {
            e.setBlock(bd);
            e.setTransformation(new Transformation(new Vector3f(0, y, 0), new Quaternionf(), new Vector3f(0.01f, 0.01f, 0.01f), new Quaternionf()));
            if (glow) e.setBrightness(new Display.Brightness(15, 15));
            e.setViewRange(2.0f);
        });
        Bukkit.getScheduler().runTaskLater(pl(), () -> animate(d, new Vector3f(-sx / 2, y, -sz / 2), new Vector3f(sx, sy, sz), growTicks), 2 + delay);
        return d;
    }
    static void animate(Display d, Vector3f trans, Vector3f scale, int ticks) {
        if (!d.isValid()) return;
        d.setInterpolationDelay(0);
        d.setInterpolationDuration(ticks);
        d.setTransformation(new Transformation(trans, new Quaternionf(), scale, new Quaternionf()));
    }

    /** straight-line projectile with ray tracing, no vanilla entity => fully custom VFX */
    static void proj(Player p, Location start, Vector dir, double speed, int life, double dmg, double aoe,
                     BiConsumer<Location, Integer> trail, Consumer<Location> impact) {
        Vector d = dir.clone().normalize();
        new BukkitRunnable() {
            final Location loc = start.clone();
            int t = 0;
            public void run() {
                World w = loc.getWorld();
                RayTraceResult r = w.rayTrace(loc, d, speed, FluidCollisionMode.NEVER, true, 0.35,
                        x -> x instanceof LivingEntity && !x.equals(p) && !(x instanceof ArmorStand));
                Vector step = d.clone().multiply(speed);
                if (r != null) {
                    Location hit = r.getHitPosition().toLocation(w);
                    Fx.line(loc, hit, 0.3, (l, i) -> trail.accept(l, 0));
                    impact.accept(hit);
                    if (aoe > 0) {
                        for (LivingEntity e : w.getNearbyLivingEntities(hit, aoe)) {
                            if (e.equals(p) || e instanceof ArmorStand) continue;
                            e.damage(dmg, p);
                            e.setVelocity(e.getLocation().toVector().subtract(hit.toVector()).normalize().multiply(0.9).setY(0.4));
                        }
                    } else if (r.getHitEntity() instanceof LivingEntity le) {
                        le.damage(dmg, p);
                    }
                    cancel();
                    return;
                }
                for (int i = 0; i < 3; i++) trail.accept(loc.clone().add(step.clone().multiply(i / 3.0)), t);
                loc.add(step);
                if (++t > life) cancel();
            }
        }.runTaskTimer(pl(), 0, 1);
    }

    // ================================================================== 1. BLOODBORN
    static boolean bloodChain(Player p) {
        LivingEntity t = target(p, 22);
        if (t == null) return fail(p, "No target in sight");
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITHER_SHOOT, 1f, 0.6f);
        claw(p);
        new BukkitRunnable() {
            int tick = 0;
            public void run() {
                if (!p.isOnline() || t.isDead()) { cancel(); return; }
                Location from = hand(p), to = center(t);
                double frac = Math.min(1, (tick + 1) / 5.0);
                Location end = from.clone().add(to.toVector().subtract(from.toVector()).multiply(frac));
                Fx.line(from, end, 0.22, (l, i) -> {
                    double sway = Math.sin(i * 0.9 + tick) * 0.05;
                    Location q = l.clone().add(0, sway, 0);
                    if (i % 2 == 0) Fx.dust(q, 150, 0, 15, 1.7f, 1, 0.01);      // chain link
                    else Fx.dust(q, 255, 40, 40, 1.0f, 1, 0.01);                 // glint
                    if (i % 5 == 0) Fx.p(q, Particle.CRIT, 1, 0.03, 0.01);
                });
                if (tick == 5) {
                    t.damage(6, p);
                    t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 2));
                    Fx.dust(to, 200, 0, 20, 2.5f, 25, 0.5);
                    Fx.p(to, Particle.DAMAGE_INDICATOR, 8, 0.4, 0.1);
                    t.getWorld().playSound(to, Sound.BLOCK_CHAIN_PLACE, 1.4f, 0.5f);
                }
                if (tick >= 5 && tick < 15) {
                    Vector pull = p.getLocation().toVector().subtract(t.getLocation().toVector());
                    if (pull.length() > 2.5) t.setVelocity(pull.normalize().multiply(1.1).setY(0.12));
                }
                if (tick >= 16) cancel();
                tick++;
            }
        }.runTaskTimer(pl(), 0, 1);
        return true;
    }

    /** three diagonal red claw slashes swept in front of the player */
    static void claw(Player p) {
        Location e = p.getEyeLocation();
        Vector d = e.getDirection();
        Vector[] b = Fx.basis(d);
        Location c = e.clone().add(d.clone().multiply(2.2));
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                double a = t / 5.0, bb = (t + 1) / 5.0;
                for (int k = -1; k <= 1; k++) {
                    Location s = c.clone().add(b[1].clone().multiply(1.4)).add(b[0].clone().multiply(-1.4 + k * 0.6));
                    Location en = c.clone().add(b[1].clone().multiply(-1.4)).add(b[0].clone().multiply(1.4 + k * 0.6));
                    Vector v = en.toVector().subtract(s.toVector());
                    for (double u = a; u < bb; u += 0.03) {
                        Location q = s.clone().add(v.clone().multiply(u));
                        Fx.dust(q, 220, 15, 25, 2.0f, 1, 0.02);
                        if (Fx.rnd(0, 1) < 0.3) Fx.p(q, Particle.CRIT, 1, 0.05, 0.02);
                    }
                }
                if (++t >= 5) cancel();
            }
        }.runTaskTimer(pl(), 0, 1);
    }

    static boolean crimsonStep(Player p) {
        LivingEntity t = target(p, 25);
        if (t == null) return fail(p, "No target in sight");
        World w = p.getWorld();
        Fx.bolt(p.getLocation(), 200, 10, 20);
        Vector behind = t.getLocation().getDirection().setY(0);
        if (behind.lengthSquared() < 1e-4) behind = new Vector(0, 0, 1);
        behind.normalize().multiply(-1.6);
        Location dest = t.getLocation().add(behind);
        if (!dest.getBlock().isPassable() || !dest.clone().add(0, 1, 0).getBlock().isPassable()) dest = t.getLocation();
        dest.setDirection(t.getLocation().toVector().subtract(dest.toVector()));
        p.teleport(dest);
        Fx.bolt(dest, 230, 20, 30);
        w.strikeLightningEffect(dest);
        w.playSound(dest, Sound.ITEM_TRIDENT_THUNDER, 1.2f, 0.7f);
        Location d2 = dest;
        Bukkit.getScheduler().runTaskLater(pl(), () -> {
            if (t.isDead()) return;
            t.damage(8, p);
            Location c = center(t);
            Fx.ring(c, 1.5, 24, l -> Fx.dust(l, 220, 10, 20, 2f, 2, 0.05));
            Fx.p(c, Particle.ELECTRIC_SPARK, 40, 0.8, 0.3);
            t.getWorld().playSound(c, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 0.6f);
        }, 6);
        return true;
    }

    // ================================================================== 2. WILDCARE
    static boolean verdantBeam(Player p) {
        Location o = p.getEyeLocation().add(0, -0.25, 0);
        Vector d = o.getDirection().normalize();
        Vector[] b = Fx.basis(d);
        Set<UUID> hit = new HashSet<>();
        p.getWorld().playSound(o, Sound.ENTITY_EVOKER_CAST_SPELL, 1.2f, 0.6f);
        p.getWorld().playSound(o, Sound.BLOCK_BEACON_ACTIVATE, 1f, 1.8f);
        new BukkitRunnable() {
            int tick = 0;
            public void run() {
                Fx.dust(hand(p), 100, 255, 120, 2.5f, 6, 0.15); // pearl charge
                for (int s = 0; s < 20; s++) {
                    double dist = (tick * 20 + s) * 0.4;
                    if (dist > 28) { cancel(); return; }
                    Location pt = o.clone().add(d.clone().multiply(dist));
                    if (!pt.getBlock().isPassable()) {
                        Fx.p(pt, Particle.HAPPY_VILLAGER, 25, 0.8, 0.2);
                        Fx.dust(pt, 90, 255, 110, 3f, 15, 0.8);
                        cancel(); return;
                    }
                    double wob = dist * 0.5 - tick * 0.7;
                    for (int k = 0; k < 6; k++) {
                        double a = k * Math.PI / 3 + wob;
                        Location q = pt.clone().add(b[0].clone().multiply(Math.cos(a) * 0.6)).add(b[1].clone().multiply(Math.sin(a) * 0.6));
                        Fx.dust(q, 40, 200, 80, 2.0f, 1, 0.0);
                    }
                    Fx.dust(pt, 170, 255, 140, 3.2f, 1, 0.1);
                    if (s % 4 == 0) Fx.p(pt, Particle.END_ROD, 1, 0.15, 0.01);
                    for (LivingEntity e : pt.getWorld().getNearbyLivingEntities(pt, 1.1)) {
                        if (e.equals(p) || e instanceof ArmorStand || !hit.add(e.getUniqueId())) continue;
                        e.damage(9, p);
                        e.setVelocity(d.clone().multiply(0.8).setY(0.3));
                        Fx.p(center(e), Particle.HAPPY_VILLAGER, 20, 0.5, 0.1);
                    }
                }
                tick++;
            }
        }.runTaskTimer(pl(), 0, 1);
        return true;
    }

    static boolean grove(Player p) {
        Location base = p.getLocation().clone();
        base.setPitch(0);
        List<Display> parts = new ArrayList<>();
        parts.add(part(base, Material.MANGROVE_LOG.createBlockData(), 0.9f, 4.6f, 0.9f, 0f, false, 20, 0));
        parts.add(part(base, Material.LIME_STAINED_GLASS.createBlockData(), 5.6f, 2.2f, 5.6f, 3.2f, true, 20, 6));
        parts.add(part(base, Material.GREEN_STAINED_GLASS.createBlockData(), 3.8f, 1.8f, 3.8f, 5.0f, true, 20, 10));
        parts.add(part(base, Material.LIME_STAINED_GLASS.createBlockData(), 2.0f, 1.4f, 2.0f, 6.5f, true, 20, 14));
        p.getWorld().playSound(base, Sound.BLOCK_AZALEA_LEAVES_PLACE, 1.4f, 0.6f);
        p.getWorld().playSound(base, Sound.BLOCK_GRASS_BREAK, 1.2f, 0.5f);
        new BukkitRunnable() {
            int tick = 0;
            public void run() {
                if (tick % 5 == 0) {
                    double r = 6 * (0.85 + 0.15 * Math.sin(tick * 0.2));
                    Fx.ring(base.clone().add(0, 0.15, 0), r, 40, l -> Fx.dust(l, 60, 230, 100, 1.4f, 1, 0.02));
                }
                Location leaf = base.clone().add(Fx.rnd(-2.5, 2.5), Fx.rnd(3, 7), Fx.rnd(-2.5, 2.5));
                Fx.dust(leaf, 90, 220, 90, 1.2f, 2, 0.2);
                Fx.p(leaf, Particle.HAPPY_VILLAGER, 1, 0.3, 0);
                if (tick % 10 == 0 && p.isOnline() && !p.isDead() && p.getWorld().equals(base.getWorld())
                        && p.getLocation().distanceSquared(base) <= 36) {
                    double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
                    p.setHealth(Math.min(max, p.getHealth() + 2));
                    Location from = base.clone().add(0, 5, 0), to = p.getLocation().add(0, 1, 0);
                    Fx.line(from, to, 0.35, (l, i) -> { Fx.dust(l, 120, 255, 140, 1.3f, 1, 0.03); if (i % 3 == 0) Fx.p(l, Particle.HAPPY_VILLAGER, 1, 0.05, 0); });
                    p.getWorld().playSound(to, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.6f, 1.6f);
                }
                if (tick == 100) {
                    for (Display d : parts) animate(d, new Vector3f(0, 0, 0), new Vector3f(0.01f, 0.01f, 0.01f), 15);
                    Bukkit.getScheduler().runTaskLater(pl(), () -> parts.forEach(Entity::remove), 17);
                    cancel(); return;
                }
                tick++;
            }
        }.runTaskTimer(pl(), 0, 1);
        return true;
    }

    // ================================================================== 3. LIGHTNING CUTLASS
    static boolean stormDrake(Player p) {
        LivingEntity t = target(p, 30);
        if (t == null) return fail(p, "No target in sight");
        int free = 0;
        for (int i = 1; i <= 25; i++) {
            Block b = t.getLocation().add(0, i + t.getHeight(), 0).getBlock();
            if (!b.isPassable()) break;
            free = i;
        }
        if (free < 8) return fail(p, "Not enough room above the target");
        final int lift = free;
        Location eye = p.getEyeLocation();
        Location start = eye.clone().add(eye.getDirection().multiply(-6)).add(0, 5, 0);
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1.5f, 1.2f);
        new BukkitRunnable() {
            int tick = 0;
            final List<Location> hist = new ArrayList<>();
            Location head = start.clone();
            Location grab;
            public void run() {
                if (!t.isValid() || t.isDead()) { cancel(); return; }
                if (tick < 24) {
                    double u = tick / 24.0, e = u * u * (3 - 2 * u);
                    Location tc = t.getLocation().add(0, 1.4, 0);
                    head = start.clone().add(tc.toVector().subtract(start.toVector()).multiply(e)).add(0, Math.sin(u * Math.PI) * 2.5, 0);
                    if (tick == 23) { grab = tc.clone(); t.damage(4, p); t.getWorld().strikeLightningEffect(tc); }
                } else if (tick < 24 + lift) {
                    head = grab.clone().add(0, tick - 24 + 1, 0);
                    Location tp = t.getLocation();
                    tp.setX(head.getX()); tp.setY(head.getY() - 1.6); tp.setZ(head.getZ());
                    t.teleport(tp);
                    t.setVelocity(new Vector(0, 0, 0));
                    t.setFallDistance(0);
                    if (tick % 4 == 0) Fx.p(tp.clone().add(0, 1, 0), Particle.ELECTRIC_SPARK, 12, 0.4, 0.2);
                } else if (tick == 24 + lift) {
                    t.setFallDistance((float) lift);
                    head.getWorld().strikeLightningEffect(head);
                    head.getWorld().playSound(head, Sound.ENTITY_ENDER_DRAGON_FLAP, 2f, 0.7f);
                    head.getWorld().playSound(head, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 1.0f);
                } else if (tick < 24 + lift + 30) {
                    head = head.clone().add(0.5, 0.8, 0.5);
                } else { cancel(); return; }
                hist.add(0, head.clone());
                if (hist.size() > 40) hist.remove(hist.size() - 1);
                drawDragon(hist, tick);
                tick++;
            }
        }.runTaskTimer(pl(), 0, 1);
        return true;
    }

    private static void drawDragon(List<Location> h, int tick) {
        if (h.size() < 3) return;
        Location head = h.get(0);
        Vector fwd = head.toVector().subtract(h.get(Math.min(2, h.size() - 1)).toVector());
        if (fwd.lengthSquared() < 1e-4) fwd = new Vector(0, 0, 1);
        fwd.normalize();
        Vector[] b = Fx.basis(fwd);
        int n = Math.min(h.size(), 38);
        for (int i = 0; i < n; i += 2) {
            Location s = h.get(i);
            double k = 1.0 - i / (double) n;
            Fx.dust(s, 90, 190, 255, (float) (1.2 + k * 1.6), 2, 0.12 + 0.2 * k);
            if (i % 4 == 0) Fx.p(s, Particle.ELECTRIC_SPARK, 2, 0.3 * k + 0.1, 0.05);
            if (i % 6 == 0) Fx.dust(s.clone().add(b[1].clone().multiply(0.5 * k + 0.2)), 255, 255, 255, 1.0f, 1, 0.02);
        }
        Location root = h.get(Math.min(6, h.size() - 1));
        double flap = Math.sin(tick * 0.45);
        for (int side = -1; side <= 1; side += 2) {
            for (int k = 1; k <= 7; k++) {
                Location wp = root.clone().add(b[0].clone().multiply(side * k * 0.7))
                        .add(b[1].clone().multiply(flap * k * 0.22 + 0.2 * k)).add(fwd.clone().multiply(-k * 0.25));
                Fx.dust(wp, 160, 225, 255, 1.1f, 1, 0.05);
                if (k % 2 == 0) Fx.p(wp, Particle.ELECTRIC_SPARK, 1, 0.05, 0.02);
                Fx.dust(wp.clone().add(fwd.clone().multiply(-0.8)), 60, 140, 255, 0.9f, 1, 0.05);
            }
        }
        Fx.dust(head, 200, 240, 255, 2.6f, 5, 0.25);
        Fx.dust(head.clone().add(fwd.clone().multiply(0.8)), 255, 255, 120, 1.8f, 3, 0.15);
        Fx.dust(head.clone().add(b[0].clone().multiply(0.3)).add(b[1].clone().multiply(0.3)), 255, 250, 80, 1.0f, 1, 0.0);
        Fx.dust(head.clone().add(b[0].clone().multiply(-0.3)).add(b[1].clone().multiply(0.3)), 255, 250, 80, 1.0f, 1, 0.0);
    }

    static boolean staticAbsorb(Player p) {
        ABSORB.put(p.getUniqueId(), System.currentTimeMillis() + 8000);
        p.getWorld().playSound(p.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1f, 1.8f);
        p.getWorld().strikeLightningEffect(p.getLocation());
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                if (!p.isOnline() || t >= 160) { ABSORB.remove(p.getUniqueId()); cancel(); return; }
                for (int k = 0; k < 2; k++) {
                    double a = t * 0.35 + k * Math.PI, y = (t * 0.07) % 2.0;
                    Location l = p.getLocation().add(Math.cos(a) * 0.9, y, Math.sin(a) * 0.9);
                    Fx.dust(l, 110, 200, 255, 1.4f, 1, 0.02);
                    Fx.p(l, Particle.ELECTRIC_SPARK, 1, 0.05, 0.02);
                }
                t++;
            }
        }.runTaskTimer(pl(), 0, 1);
        return true;
    }

    // ================================================================== 4. VOID BOW
    static boolean voidVolley(Player p) {
        Location eye = p.getEyeLocation();
        Vector d = eye.getDirection().normalize();
        Location s = hand(p);
        p.getWorld().playSound(eye, Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.7f);
        p.getWorld().playSound(eye, Sound.ENTITY_ARROW_SHOOT, 1f, 0.6f);
        for (double yaw : new double[]{-9, 0, 9}) {
            Vector dir = d.clone().rotateAroundY(Math.toRadians(yaw));
            proj(p, s, dir, 1.7, 40, 7, 0,
                    (l, t) -> {
                        Fx.dust(l, 130, 70, 230, 0.9f, 1, 0.03);
                        if (t % 2 == 0) Fx.p(l, Particle.REVERSE_PORTAL, 1, 0.04, 0.01);
                        Fx.dust(l.clone().add(dir.clone().multiply(0.5)), 220, 190, 255, 0.7f, 1, 0.0);
                    },
                    l -> {
                        Fx.p(l, Particle.REVERSE_PORTAL, 20, 0.3, 0.2);
                        Fx.dust(l, 150, 80, 255, 1.6f, 10, 0.3);
                        l.getWorld().playSound(l, Sound.ENTITY_ENDERMAN_HURT, 0.8f, 1.5f);
                    });
        }
        return true;
    }

    static boolean convergence(Player p) {
        if (left(p, "void_bow:1") > 0) return fail(p, "Convergence only works while Void Volley is ready");
        cd(p, "void_bow:1", 6); // using this consumes the volley
        Location eye = p.getEyeLocation();
        Vector d = eye.getDirection().normalize();
        Vector[] b = Fx.basis(d);
        p.getWorld().playSound(eye, Sound.ENTITY_WARDEN_SONIC_CHARGE, 1.2f, 1.6f);
        p.getWorld().playSound(eye, Sound.BLOCK_END_PORTAL_SPAWN, 0.6f, 2f);
        proj(p, hand(p), d, 1.4, 55, 24, 3.2,
                (l, t) -> {
                    double rad = Math.max(0, 1.5 - t * 0.12), ang = t * 0.9;
                    for (int k = 0; k < 3; k++) {
                        double a = ang + k * Math.PI * 2 / 3;
                        Location q = l.clone().add(b[0].clone().multiply(Math.cos(a) * rad)).add(b[1].clone().multiply(Math.sin(a) * rad));
                        Fx.dust(q, 150, 80, 255, 1.2f, 1, 0.0);
                    }
                    if (rad < 0.1) {
                        Fx.dust(l, 190, 120, 255, 3.2f, 2, 0.1);
                        Fx.dust(l, 20, 0, 40, 4f, 1, 0.05);
                        Fx.p(l, Particle.REVERSE_PORTAL, 3, 0.2, 0.05);
                        Fx.p(l, Particle.END_ROD, 1, 0.1, 0.01);
                    }
                },
                l -> {
                    Fx.ring(l, 1.0, 20, q -> Fx.dust(q, 150, 80, 255, 2.5f, 2, 0.1));
                    Fx.ring(l, 2.5, 36, q -> Fx.dust(q, 90, 30, 200, 2.0f, 1, 0.1));
                    Fx.p(l, Particle.REVERSE_PORTAL, 80, 1.5, 0.4);
                    Fx.p(l, Particle.EXPLOSION, 1, 0, 0);
                    l.getWorld().playSound(l, Sound.ENTITY_GENERIC_EXPLODE, 1.2f, 0.7f);
                    l.getWorld().playSound(l, Sound.ENTITY_ENDER_DRAGON_HURT, 1f, 1.4f);
                });
        return true;
    }

    // ================================================================== 5. WARLOCK'S AXE
    static boolean volcano(Player p) {
        World w = p.getWorld();
        Location base = p.getLocation().add(p.getLocation().getDirection().setY(0).normalize().multiply(5));
        RayTraceResult r = w.rayTraceBlocks(base.clone().add(0, 3, 0), new Vector(0, -1, 0), 8, FluidCollisionMode.NEVER, true);
        if (r == null) return fail(p, "No ground there");
        base.setY(r.getHitPosition().getY());
        List<Display> parts = new ArrayList<>();
        parts.add(part(base, Material.BASALT.createBlockData(), 6.0f, 1.0f, 6.0f, 0f, false, 18, 0));
        parts.add(part(base, Material.SMOOTH_BASALT.createBlockData(), 4.4f, 1.0f, 4.4f, 1f, false, 18, 6));
        parts.add(part(base, Material.MAGMA_BLOCK.createBlockData(), 2.8f, 1.0f, 2.8f, 2f, true, 18, 12));
        parts.add(part(base, Material.ORANGE_STAINED_GLASS.createBlockData(), 1.5f, 0.5f, 1.5f, 2.9f, true, 18, 18));
        w.playSound(base, Sound.ENTITY_GENERIC_EXPLODE, 1.5f, 0.5f);
        w.playSound(base, Sound.BLOCK_LAVA_AMBIENT, 2f, 0.6f);
        Location top = base.clone().add(0, 3.2, 0);
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                if (t == 200) {
                    for (Display d : parts) animate(d, new Vector3f(0, 0, 0), new Vector3f(0.01f, 0.01f, 0.01f), 20);
                    Bukkit.getScheduler().runTaskLater(pl(), () -> parts.forEach(Entity::remove), 22);
                    cancel(); return;
                }
                if (t > 30) {
                    for (int i = 0; i < 4; i++) {
                        Vector v = new Vector(Fx.rnd(-0.25, 0.25), Fx.rnd(0.6, 1.1), Fx.rnd(-0.25, 0.25));
                        Fx.dir(top, Particle.FLAME, v, 0.8);
                    }
                    Fx.p(top, Particle.LAVA, 2, 0.4, 0);
                    Fx.p(top.clone().add(0, 1, 0), Particle.LARGE_SMOKE, 2, 0.4, 0.05);
                    Location rim = base.clone().add(Fx.rnd(-1.2, 1.2), 2.4, Fx.rnd(-1.2, 1.2));
                    Fx.p(rim, Particle.FALLING_LAVA, 1, 0.1, 0);
                }
                if (t % 20 == 0 && t > 30) {
                    w.playSound(top, Sound.ENTITY_GENERIC_EXPLODE, 0.6f, 0.6f);
                    for (int i = 0; i < 40; i++) {
                        Vector v = new Vector(Fx.rnd(-0.6, 0.6), Fx.rnd(0.9, 1.6), Fx.rnd(-0.6, 0.6));
                        Fx.dir(top, i % 3 == 0 ? Particle.LAVA : Particle.FLAME, v, 0.7);
                    }
                }
                if (t % 10 == 0 && t > 30) {
                    for (LivingEntity e : w.getNearbyLivingEntities(base, 6, 6, 6)) {
                        if (e.equals(p) || e instanceof ArmorStand) continue;
                        e.setFireTicks(100);
                        e.damage(1.5, p);
                    }
                    Fx.ring(base.clone().add(0, 0.2, 0), 6, 48, l -> Fx.p(l, Particle.FLAME, 1, 0.05, 0.01));
                }
                t++;
            }
        }.runTaskTimer(pl(), 0, 1);
        return true;
    }

    static boolean shatter(Player p) {
        Location c = p.getLocation();
        World w = p.getWorld();
        w.playSound(c, Sound.ITEM_MACE_SMASH_GROUND_HEAVY, 1.5f, 0.7f);
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                double r = (t + 1);
                Fx.ring(c.clone().add(0, 0.3, 0), r, (int) (r * 8), l -> {
                    Fx.dust(l, 170, 170, 175, 1.6f, 1, 0.05);
                    if (Fx.rnd(0, 1) < 0.25) Fx.p(l, Particle.CRIT, 1, 0.1, 0.1);
                });
                if (++t >= 8) cancel();
            }
        }.runTaskTimer(pl(), 0, 1);
        int hits = 0;
        for (Player o : w.getNearbyPlayers(c, 8)) {
            if (o.equals(p)) continue;
            boolean had = false;
            for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HAND, EquipmentSlot.OFF_HAND}) {
                ItemStack it = o.getInventory().getItem(s);
                if (it == null || it.getType() != Material.SHIELD) continue;
                had = true;
                ItemMeta m = it.getItemMeta();
                if (m instanceof Damageable dm) {
                    int max = Material.SHIELD.getMaxDurability();
                    // direct durability write => Unbreaking can never reduce it
                    dm.setDamage(dm.getDamage() + (int) Math.ceil(max * 0.30));
                    if (dm.getDamage() >= max) {
                        o.getInventory().setItem(s, null);
                        w.playSound(o.getLocation(), Sound.ITEM_SHIELD_BREAK, 1f, 1f);
                    } else {
                        it.setItemMeta(dm);
                        o.getInventory().setItem(s, it);
                    }
                }
            }
            if (had) {
                hits++;
                o.setCooldown(Material.SHIELD, 120);
                w.playSound(o.getLocation(), Sound.ITEM_SHIELD_BREAK, 1f, 0.8f);
                Fx.p(o.getLocation().add(0, 1, 0), Particle.CRIT, 30, 0.5, 0.3);
            }
        }
        p.sendActionBar(Component.text(hits == 0 ? "No shields nearby" : "Shattered " + hits + " shield(s)", NamedTextColor.GOLD));
        return true;
    }

    // ================================================================== 6. DEATH'S HOOK
    static boolean soulHaul(Player p) {
        Collection<LivingEntity> list = p.getWorld().getNearbyLivingEntities(p.getLocation(), 30, 30, 30,
                e -> !e.equals(p) && !(e instanceof ArmorStand));
        if (list.isEmpty()) return fail(p, "Nothing within 30 blocks");
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.8f, 0.5f);
        p.getWorld().playSound(p.getLocation(), Sound.PARTICLE_SOUL_ESCAPE, 2f, 0.5f);
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                if (!p.isOnline()) { cancel(); return; }
                double r = 30.0 * (1 - t / 14.0);
                Fx.ring(p.getLocation().add(0, 0.3, 0), Math.max(1, r), 64, l -> {
                    Fx.dust(l, 15, 0, 25, 2.2f, 1, 0.1);
                    Fx.p(l, Particle.SMOKE, 1, 0.1, 0.02);
                });
                for (LivingEntity e : list) {
                    if (!e.isValid() || e.isDead()) continue;
                    Vector pull = p.getLocation().toVector().subtract(e.getLocation().toVector());
                    double dist = pull.length();
                    Location c = center(e);
                    Fx.line(c, p.getLocation().add(0, 1, 0), 1.0, (l, i) -> {
                        if (i % 2 == 0) Fx.dust(l, 10, 0, 20, 1.6f, 1, 0.05);
                        else Fx.p(l, Particle.SQUID_INK, 1, 0.05, 0.01);
                    });
                    Fx.p(c, Particle.SOUL, 2, 0.3, 0.02);
                    if (dist > 2.2) e.setVelocity(pull.normalize().multiply(Math.min(1.6, 0.35 + dist * 0.06)).setY(0.18));
                    if (t == 0) e.damage(3, p);
                }
                if (++t >= 14) cancel();
            }
        }.runTaskTimer(pl(), 0, 1);
        return true;
    }

    static void applyStun(LivingEntity e, int ticks) {
        STUN.put(e.getUniqueId(), System.currentTimeMillis() + ticks * 50L);
        boolean hadAI = e instanceof Mob m && m.hasAI();
        if (e instanceof Mob m) m.setAI(false);
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                if (t >= ticks || !e.isValid() || e.isDead()) {
                    if (e instanceof Mob mm && hadAI) mm.setAI(true);
                    STUN.remove(e.getUniqueId());
                    cancel(); return;
                }
                if (t % 4 == 0) {
                    Fx.bolt(e.getLocation(), 15, 0, 25);
                    Fx.p(center(e), Particle.SMOKE, 8, 0.4, 0.05);
                    Fx.dust(center(e), 90, 20, 160, 1.5f, 6, 0.5);
                }
                t++;
            }
        }.runTaskTimer(pl(), 0, 1);
    }

    static boolean blackLightning(Player p) {
        Collection<LivingEntity> list = p.getWorld().getNearbyLivingEntities(p.getLocation(), 14, 14, 14,
                e -> !e.equals(p) && !(e instanceof ArmorStand));
        if (list.isEmpty()) return fail(p, "No enemies nearby");
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5f, 0.5f);
        for (LivingEntity e : list) {
            applyStun(e, 60); // 3 seconds
            e.getWorld().playSound(e.getLocation(), Sound.ENTITY_WARDEN_SONIC_BOOM, 0.6f, 1.6f);
        }
        return true;
    }

    // ================================================================== 7. MIDAS REAVER (gold, from the slot)
    static boolean gildedNova(Player p) {
        Location c = p.getLocation();
        Set<UUID> hit = new HashSet<>();
        c.getWorld().playSound(c, Sound.BLOCK_BELL_RESONATE, 2f, 0.6f);
        c.getWorld().playSound(c, Sound.ENTITY_GENERIC_EXPLODE, 1f, 1.4f);
        new BukkitRunnable() {
            int t = 0;
            public void run() {
                double r = (t + 1) * 1.0;
                Fx.ring(c.clone().add(0, 0.4, 0), r, (int) (r * 10), l -> {
                    Fx.dust(l, 255, 200, 40, 2.0f, 1, 0.05);
                    if (Fx.rnd(0, 1) < 0.2) Fx.p(l, Particle.END_ROD, 1, 0.05, 0.05);
                });
                for (LivingEntity e : c.getWorld().getNearbyLivingEntities(c, r, 3, r)) {
                    if (e.equals(p) || e instanceof ArmorStand || !hit.add(e.getUniqueId())) continue;
                    e.damage(10, p);
                    e.setVelocity(e.getLocation().toVector().subtract(c.toVector()).normalize().multiply(1.1).setY(0.5));
                }
                if (++t >= 8) cancel();
            }
        }.runTaskTimer(pl(), 0, 1);
        return true;
    }

    static boolean coinBarrage(Player p) {
        Location s = hand(p);
        Vector d = p.getEyeLocation().getDirection().normalize();
        p.getWorld().playSound(s, Sound.ENTITY_ITEM_PICKUP, 1.2f, 0.5f);
        for (int i = -2; i <= 2; i++) {
            Vector dir = d.clone().rotateAroundY(Math.toRadians(i * 6));
            proj(p, s, dir, 1.5, 30, 6, 0,
                    (l, t) -> { Fx.dust(l, 255, 205, 50, 1.5f, 1, 0.02); if (t % 3 == 0) Fx.p(l, Particle.END_ROD, 1, 0.02, 0); },
                    l -> { Fx.dust(l, 255, 215, 60, 2f, 12, 0.3); l.getWorld().playSound(l, Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.6f); });
        }
        return true;
    }
}
