# WeaponCraft (Paper 1.21.11)

## Build
    mvn package            # -> target/WeaponCraft.jar  (Java 21)
Drop the jar into `plugins/`.

## Resource pack
`WeaponCraft-pack.zip` is pre-built (regenerate/edit with `python3 resourcepack-tools/build_pack.py`).
Host it and set `resource-pack.url` + `sha1` in `plugins/WeaponCraft/config.yml`,
or put the same url/sha1 in server.properties. Items use `setItemModel("weaponcraft:<id>")`,
so the pack needs `assets/weaponcraft/items/<id>.json` (included).
pack_format 75 = 1.21.11 (change it if your client complains).

## Controls
Right-click = ability 1 | Sneak+Right-click or F = ability 2
Void Bow ability 2 only works while ability 1 is off cooldown.

## Commands
/weapons (alias /wc)  - weapon GUI        /roll weapons - Gambling Slot
Perms: weaponcraft.use (default), weaponcraft.give (default), weaponcraft.admin (op)
