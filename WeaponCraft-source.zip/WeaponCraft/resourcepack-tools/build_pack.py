#!/usr/bin/env python3
"""Generates WeaponCraft-pack.zip: 3D (multi-cuboid) item models + palette texture.
Item model definitions use the 1.21.4+ `assets/<ns>/items/<id>.json` format (matches setItemModel)."""
import json, os, struct, zlib, zipfile, shutil, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "WeaponCraft-pack"
NS = "weaponcraft"

PALETTE = [  # 16 colours, 4x4 cells of 4px
 (90,0,10),(200,20,30),(255,60,60),(35,35,45),
 (170,175,190),(225,230,240),(255,200,50),(110,70,35),
 (40,170,70),(140,255,120),(100,200,255),(120,40,200),
 (40,10,70),(255,120,20),(60,60,60),(255,255,255)]
DR,R,BR,BLK,ST,LST,GLD,WOOD,GRN,LIME,CYAN,PUR,DPUR,ORG,DGR,WHT = range(16)

def png(path, w, h, px):
    raw = b"".join(b"\x00" + b"".join(bytes(px[y][x]) for x in range(w)) for y in range(h))
    def chunk(t, d): 
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    data = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) \
        + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b"")
    open(path, "wb").write(data)

def cell_uv(c):
    col, row = c % 4, c // 4
    return [col*4+1, row*4+1, col*4+3, row*4+3]

class M:
    def __init__(self): self.el = []
    def cube(self, x0,y0,z0,x1,y1,z1,c):
        uv = cell_uv(c)
        f = {k: {"uv": uv, "texture": "#0"} for k in ("north","south","east","west","up","down")}
        self.el.append({"from":[round(x0,3),round(y0,3),round(z0,3)],"to":[round(x1,3),round(y1,3),round(z1,3)],"faces":f})
    def diag(self, x0,y0,x1,y1,w,c,t=1.4,z=8):
        n = max(1, int(max(abs(x1-x0), abs(y1-y0))*2))
        for i in range(n+1):
            x = x0+(x1-x0)*i/n; y = y0+(y1-y0)*i/n
            self.cube(x-w/2,y-w/2,z-t/2,x+w/2,y+w/2,z+t/2,c)

DISPLAY_HELD = {
 "thirdperson_righthand":{"rotation":[0,-90,55],"translation":[0,4.0,0.5],"scale":[0.85,0.85,0.85]},
 "thirdperson_lefthand":{"rotation":[0,90,-55],"translation":[0,4.0,0.5],"scale":[0.85,0.85,0.85]},
 "firstperson_righthand":{"rotation":[0,-90,25],"translation":[1.13,3.2,1.13],"scale":[0.68,0.68,0.68]},
 "firstperson_lefthand":{"rotation":[0,90,-25],"translation":[1.13,3.2,1.13],"scale":[0.68,0.68,0.68]},
 "gui":{"rotation":[12,-28,0],"translation":[0,0,0],"scale":[0.95,0.95,0.95]},
 "ground":{"rotation":[0,0,0],"translation":[0,2,0],"scale":[0.5,0.5,0.5]},
 "fixed":{"rotation":[0,180,0],"translation":[0,0,0],"scale":[1,1,1]},
}
DISPLAY_BLOCK = {
 "gui":{"rotation":[30,225,0],"translation":[0,0,0],"scale":[0.7,0.7,0.7]},
 "thirdperson_righthand":{"rotation":[75,45,0],"translation":[0,2.5,0],"scale":[0.5,0.5,0.5]},
 "firstperson_righthand":{"rotation":[0,45,0],"translation":[0,0,0],"scale":[0.45,0.45,0.45]},
 "ground":{"translation":[0,3,0],"scale":[0.4,0.4,0.4]},
 "fixed":{"scale":[0.6,0.6,0.6]},
}

def sword(m, blade, edge, fuller, guard, grip, pommel, tip=None):
    m.diag(5,5,13.5,13.5,2.4,blade,1.4)
    m.diag(5.5,5.5,13,13,3.0,edge,0.7)           # thin bevel sandwich
    m.diag(6,6,13,13,0.9,fuller,1.9)
    m.diag(3.6,7.4,7.4,3.6,1.5,guard,2.2)
    m.diag(1.8,1.8,4,4,1.4,grip,1.5)
    m.cube(0.6,0.6,7,2.2,2.2,9,pommel)

def build():
    models = {}

    m = M(); sword(m, BLK, DR, BR, DR, WOOD, R)
    m.diag(4.3,8.2,2.4,12.2,0.9,BR,1.0,z=6.6); m.diag(5.6,8.8,4.2,13,0.9,BR,1.0,z=9.4)  # claws
    m.diag(3.4,7.5,1.5,10.5,0.8,R,1.0,z=8)
    models["bloodborn"] = (m, DISPLAY_HELD)

    m = M()
    m.diag(2,2,12,12,1.3,WOOD,1.3)
    m.cube(11.2,11.2,7.2,14.8,14.8,10.8,LIME)         # green pearl
    m.cube(11.6,11.6,6.8,14.4,14.4,11.2,GRN)
    m.cube(10.2,11.4,7.2,11.2,15.6,8.8,GRN); m.cube(11.4,10.2,7.2,15.6,11.2,8.8,GRN)  # prongs
    m.diag(5,5,9,9,1.8,GRN,1.6)
    models["wildcare"] = (m, DISPLAY_HELD)

    m = M()
    m.diag(5,5,12,12,2.1,ST,1.2); m.diag(12,12,14.8,14.4,1.7,LST,1.0)
    m.diag(6,4.6,12.6,11.2,0.8,CYAN,1.8)
    m.diag(3.6,7.2,7.2,3.6,1.6,GLD,2.4); m.diag(1.8,1.8,4,4,1.4,WOOD,1.5)
    m.cube(0.6,0.6,7,2.2,2.2,9,GLD)
    models["lightning_cutlass"] = (m, DISPLAY_HELD)

    m = M()
    pts = [(2,14),(2.5,10),(4,6.5),(6.5,4),(10,2.5),(14,2)]
    for a,b in zip(pts, pts[1:]): m.diag(a[0],a[1],b[0],b[1],1.8,DPUR,1.8)
    m.diag(2,14,14,2,0.5,LST,0.5)                      # string
    m.cube(4.4,4.4,7,6.4,6.4,9,PUR)                   # void gem
    for a in pts[1:-1]: m.cube(a[0]-0.4,a[1]-0.4,6.6,a[0]+0.4,a[1]+0.4,9.4,PUR)
    models["void_bow"] = (m, DISPLAY_HELD)

    m = M()
    m.diag(2,2,12,12,1.3,WOOD,1.4)
    m.diag(9,14.5,14.5,9,4.2,BLK,2.6); m.diag(10.4,15.6,15.6,10.4,1.0,ORG,2.8)
    m.diag(8.4,10.2,6.2,12.4,1.3,DGR,1.4)
    m.cube(10.8,10.8,6.4,12.2,12.2,9.6,ORG)
    models["warlocks_axe"] = (m, DISPLAY_HELD)

    m = M()
    m.diag(2,2,12,12,1.2,DGR,1.3); m.diag(3,3,11,11,0.6,DPUR,1.9)
    m.diag(12,12,14.6,14.2,1.6,BLK,1.4); m.diag(14.6,14.2,15,11.6,1.6,BLK,1.4)
    m.diag(15,11.6,13.4,9.6,1.6,BLK,1.4); m.cube(12.8,9.0,7.2,14.2,10.2,8.8,LST)
    m.cube(1.2,1.2,7.2,2.6,2.6,8.8,PUR)
    models["deaths_hook"] = (m, DISPLAY_HELD)

    m = M(); sword(m, GLD, GLD, ORG, GLD, WOOD, R)
    m.cube(5.6,5.6,6.4,7,7,9.6,R)
    models["midas_reaver"] = (m, DISPLAY_HELD)

    m = M()
    m.cube(2,0,3,14,13,13,GLD); m.cube(1,0,2,15,2,14,DGR)
    m.cube(4,6,12.8,12,11,13.6,BLK)
    m.cube(4.6,6.6,13.4,6.6,10.4,13.9,R); m.cube(7,6.6,13.4,9,10.4,13.9,CYAN); m.cube(9.4,6.6,13.4,11.4,10.4,13.9,LIME)
    m.cube(4,2.5,12.8,12,5,13.6,DGR)
    m.cube(14,6,7.2,15.5,12,8.8,ST); m.cube(14.2,12,6.8,16,14,9.2,R)
    m.cube(3,13,5,13,14.5,11,ORG)
    models["gambling_slot"] = (m, DISPLAY_BLOCK)
    return models

def main():
    if os.path.exists(OUT): shutil.rmtree(OUT)
    base = f"{OUT}/assets/{NS}"
    for d in ("models/item","items","textures/item"): os.makedirs(f"{base}/{d}")
    px = [[(0,0,0,0)]*16 for _ in range(16)]
    px = [[None]*16 for _ in range(16)]
    for y in range(16):
        for x in range(16):
            px[y][x] = (*PALETTE[(y//4)*4 + x//4], 255)
    png(f"{base}/textures/item/palette.png", 16, 16, px)
    json.dump({"pack":{"pack_format":75,"description":"WeaponCraft 3D weapons"}}, open(f"{OUT}/pack.mcmeta","w"), indent=1)
    for name,(m,disp) in build().items():
        model = {"textures":{"0":f"{NS}:item/palette","particle":f"{NS}:item/palette"},
                 "gui_light":"front","elements":m.el,"display":disp}
        json.dump(model, open(f"{base}/models/item/{name}.json","w"))
        json.dump({"model":{"type":"minecraft:model","model":f"{NS}:item/{name}"}}, open(f"{base}/items/{name}.json","w"))
    zf = OUT + ".zip"
    with zipfile.ZipFile(zf,"w",zipfile.ZIP_DEFLATED) as z:
        for root,_,files in os.walk(OUT):
            for f in files:
                full = os.path.join(root,f); z.write(full, os.path.relpath(full, OUT))
    print("built", zf)
main()
